
package toyThreads.util;

public class Debug {
    public static int DEBUG_VALUE;

}