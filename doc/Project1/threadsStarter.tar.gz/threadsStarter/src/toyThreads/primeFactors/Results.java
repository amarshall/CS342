
package toyThreads.primeFactors;

import toyThreads.util.Debug;
import java.util.ArrayList;
import java.util.Iterator;

public class Results {

    // FIXME: instantiate the arrayList here, instead of setting it to null;
    private static ArrayList<Integer> factorsFound = null;

    // FIXME: change this to a private constructor
    public Results() {}

    // FIXME: make this method thread-safe
    public static void addFactor(int newFactor) {
	// FIXME
    }

    public static void printFactors() {
	// FIXME: all the factors in the ArrayList should be printed here
    }
}
